<template>
    <div class="apply-container">
        <h2>Apply for a Job</h2>
        <form @submit.prevent="applyJob">
            <input v-model="jobUrl" type="url" placeholder="Enter the job URL here" required class="url-input" />
            <button type="submit" class="submit-btn">Apply</button>
        </form>
        <p v-if="isLoading" class="loading-message">Processing your application...</p>
        <p v-if="errorMessage" class="error-message">{{ errorMessage }}</p>
    </div>
</template>

<script lang="ts">
import { defineComponent, ref } from 'vue';
import axios from 'axios';

export default defineComponent({
    name: 'Apply',
    setup() {
        const jobUrl = ref('');
        const isLoading = ref(false);
        const errorMessage = ref<string | null>(null);

        // Function to apply for the job
        const applyJob = async () => {
            isLoading.value = true;
            errorMessage.value = null;

            try {
                // Post the job URL to your backend for processing
                const response = await axios.post('http://localhost:5000/apply', {
                    job_url: jobUrl.value,
                });

                if (response.data.success) {
                    // Handle success response
                    alert('Job application is being filled automatically!');
                } else {
                    // Handle error from backend
                    errorMessage.value = 'Failed to process your application.';
                }
            } catch (error) {
                // Handle network or server errors
                errorMessage.value = 'An error occurred while applying for the job. Please try again later.';
            } finally {
                isLoading.value = false;
            }
        };

        return {
            jobUrl,
            applyJob,
            isLoading,
            errorMessage,
        };
    },
});
</script>

<style scoped>
.apply-container {
    max-width: 600px;
    margin: 0 auto;
    padding: 20px;
    text-align: center;
    border-radius: 8px;
    background-color: #f7f7f7;
}

.url-input {
    width: 100%;
    padding: 10px;
    margin: 10px 0;
    border-radius: 5px;
    border: 1px solid #ddd;
}

.submit-btn {
    width: 100%;
    padding: 10px;
    border-radius: 5px;
    background-color: #007BFF;
    color: white;
    border: none;
}

.loading-message {
    margin-top: 15px;
    font-style: italic;
    color: #007BFF;
}

.error-message {
    margin-top: 15px;
    color: red;
}
</style>
