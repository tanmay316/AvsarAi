<script setup lang="ts">
import { RouterView } from 'vue-router';
import { ref, onMounted } from 'vue';

const isDarkMode = ref(true);

onMounted(() => {
  document.documentElement.classList.toggle('dark', isDarkMode.value);
});
</script>

<template>
  <div class="app dark">
    <div class="gradient-bg"></div>
    <div class="stars"></div>
    <div class="twinkling"></div>
    <div class="clouds"></div>
    <div class="tech-grid"></div>
    
    <header class="header">
      <div class="logo">AvsarAI</div>
      <nav class="nav">
        <router-link to="/" class="nav-link">Home</router-link>
        <router-link to="/profile" class="nav-link">Profile</router-link>
        <router-link to="/apply" class="nav-link">Apply</router-link>
        <router-link to="/pricing" class="nav-link">Pricing</router-link>
        <router-link to="/about" class="nav-link">About</router-link>
        <router-link to="/register" class="nav-link signup">Sign Up Free</router-link>
      </nav>
    </header>

    <main class="main-content">
      <router-view v-slot="{ Component }">
        <transition name="fade" mode="out-in">
          <component :is="Component" />
        </transition>
      </router-view>
    </main>
  </div>
</template>

<style>
/* Global styles */
:root {
  --primary: #6C63FF;
  --secondary: #00D9FF;
  --accent: #FF3D71;
  --dark: #0F1021;
  --darker: #080A17;
  --text: #E9ECEF;
}

* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  border-width: 0;
  border-style: solid;
  border-color: #e5e7eb;
}

body {
  font-family: 'Space Grotesk', sans-serif;
  line-height: 1.6;
  color: var(--text);
  background-color: var(--darker);
  min-height: 100vh;
  overflow-x: hidden;
}

/* App specific styles */
.app {
  position: relative;
  min-height: 100vh;
  overflow: hidden;
}

.gradient-bg {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: linear-gradient(135deg, 
    rgba(108, 99, 255, 0.1),
    rgba(0, 217, 255, 0.1),
    rgba(255, 61, 113, 0.1)
  );
  z-index: -4;
}

.tech-grid {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-image: 
    linear-gradient(rgba(108, 99, 255, 0.1) 1px, transparent 1px),
    linear-gradient(90deg, rgba(108, 99, 255, 0.1) 1px, transparent 1px);
  background-size: 50px 50px;
  z-index: -3;
  animation: gridMove 20s linear infinite;
}

.stars {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 100 100"><circle cx="50" cy="50" r="1" fill="white"/></svg>') repeat;
  background-size: 1px 1px;
  opacity: 0.3;
  z-index: -2;
  animation: twinkle 4s infinite;
}

.twinkling {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 100 100"><circle cx="50" cy="50" r="1" fill="white"/></svg>') repeat;
  background-size: 2px 2px;
  opacity: 0.1;
  z-index: -1;
  animation: twinkle 2s infinite;
}

.clouds {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 100 100"><path d="M20,50 Q30,40 40,50 T60,50 T80,50" stroke="white" fill="none" stroke-width="0.5"/></svg>') repeat;
  background-size: 100px 100px;
  opacity: 0.05;
  z-index: -1;
  animation: moveClouds 20s linear infinite;
}

.header {
  padding: 1.5rem 2rem;
  display: flex;
  justify-content: space-between;
  align-items: center;
  position: relative;
  z-index: 1;
  background: rgba(15, 16, 33, 0.5);
  backdrop-filter: blur(10px);
  border-bottom: 1px solid rgba(255, 255, 255, 0.1);
}

.logo {
  font-size: 1.5rem;
  font-weight: 800;
  background: linear-gradient(45deg, 
    var(--primary),
    var(--secondary),
    var(--accent)
  );
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  animation: glow 2s ease-in-out infinite alternate;
}

.nav {
  display: flex;
  align-items: center;
  gap: 2rem;
}

.nav-link {
  color: var(--text);
  text-decoration: none;
  font-weight: 500;
  padding: 0.5rem 1rem;
  border-radius: 0.5rem;
  transition: all 0.3s ease;
  position: relative;
}

.nav-link::after {
  content: '';
  position: absolute;
  bottom: 0;
  left: 0;
  width: 100%;
  height: 2px;
  background: linear-gradient(45deg, 
    var(--primary),
    var(--secondary)
  );
  transform: scaleX(0);
  transition: transform 0.3s ease;
}

.nav-link:hover {
  color: var(--text);
  background: rgba(108, 99, 255, 0.1);
}

.nav-link:hover::after {
  transform: scaleX(1);
}

.nav-link.router-link-active {
  color: var(--primary);
}

.nav-link.router-link-active::after {
  transform: scaleX(1);
}

.nav-link.signup {
  background: linear-gradient(45deg, 
    var(--primary),
    var(--secondary),
    var(--accent)
  );
  color: var(--darker);
  padding: 0.5rem 1.5rem;
  border-radius: 0.5rem;
  font-weight: 600;
  position: relative;
  overflow: hidden;
}

.nav-link.signup::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: linear-gradient(45deg, 
    rgba(255, 255, 255, 0.1),
    rgba(255, 255, 255, 0.2)
  );
  transform: translateX(-100%);
  transition: transform 0.3s ease;
}

.nav-link.signup:hover::before {
  transform: translateX(100%);
}

.nav-link.signup:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 20px rgba(108, 99, 255, 0.4);
}

.main-content {
  max-width: 1400px;
  margin: 0 auto;
  padding: 0 2rem;
  position: relative;
  z-index: 1;
}

/* Animations */
@keyframes gridMove {
  0% { background-position: 0 0; }
  100% { background-position: 50px 50px; }
}

@keyframes twinkle {
  0%, 100% { opacity: 0.3; }
  50% { opacity: 0.1; }
}

@keyframes moveClouds {
  0% { background-position: 0 0; }
  100% { background-position: 100px 100px; }
}

@keyframes glow {
  from {
    text-shadow: 0 0 10px rgba(108, 99, 255, 0.5),
                 0 0 20px rgba(108, 99, 255, 0.3),
                 0 0 30px rgba(108, 99, 255, 0.2);
  }
  to {
    text-shadow: 0 0 20px rgba(108, 99, 255, 0.8),
                 0 0 30px rgba(108, 99, 255, 0.5),
                 0 0 40px rgba(108, 99, 255, 0.3);
  }
}

/* Transitions */
.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.3s ease;
}

.fade-enter-from,
.fade-leave-to {
  opacity: 0;
}

/* Responsive design */
@media (max-width: 768px) {
  .header {
    flex-direction: column;
    gap: 1rem;
    padding: 1rem;
  }

  .nav {
    flex-wrap: wrap;
    justify-content: center;
    gap: 1rem;
  }

  .nav-link {
    padding: 0.5rem;
  }
}
</style>
