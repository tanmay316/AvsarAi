<script setup lang="ts">
import { ref } from 'vue';
import { useRouter } from 'vue-router';
import axios from 'axios';

const router = useRouter();
const jobUrl = ref('');
const error = ref('');
const success = ref('');

const handleSubmit = async () => {
  try {
    error.value = '';
    success.value = '';
    
    const response = await axios.post('/api/apply', {
      job_url: jobUrl.value
    });
    
    if (response.data.message === 'Job application is being filled automatically!') {
      success.value = 'Job application process started! Our AI agents will handle the application for you.';
      setTimeout(() => {
        router.push('/profile');
      }, 3000);
    }
  } catch (err: any) {
    error.value = err.response?.data?.error || 'Failed to submit job application';
  }
};
</script>

<template>
  <div class="apply-container">
    <h2>Apply for a Job</h2>
    
    <form @submit.prevent="handleSubmit" class="apply-form">
      <div class="form-group">
        <label for="job_url">Job URL:</label>
        <input
          type="url"
          id="job_url"
          v-model="jobUrl"
          required
          placeholder="Enter the job posting URL"
        />
        <p class="help-text">Our AI agents will automatically fill out the application form for you.</p>
      </div>
      
      <div v-if="error" class="error-message">
        {{ error }}
      </div>
      
      <div v-if="success" class="success-message">
        {{ success }}
      </div>
      
      <button type="submit" class="submit-button">Start Application</button>
    </form>
  </div>
</template>

<style scoped>
.apply-container {
  max-width: 600px;
  margin: 0 auto;
  padding: 20px;
}

.apply-form {
  background-color: #fff;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  padding: 20px;
  margin-top: 20px;
}

.form-group {
  display: flex;
  flex-direction: column;
  gap: 8px;
  margin-bottom: 20px;
}

label {
  font-weight: bold;
}

input {
  padding: 8px;
  border: 1px solid #ddd;
  border-radius: 4px;
  font-size: 16px;
}

.help-text {
  color: #666;
  font-size: 14px;
  margin-top: 5px;
}

.error-message {
  color: #ff4444;
  margin: 10px 0;
  padding: 10px;
  background-color: #ffebee;
  border-radius: 4px;
}

.success-message {
  color: #42b983;
  margin: 10px 0;
  padding: 10px;
  background-color: #e8f5e9;
  border-radius: 4px;
}

.submit-button {
  padding: 12px 24px;
  background-color: #42b983;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-size: 16px;
  transition: background-color 0.3s;
}

.submit-button:hover {
  background-color: #3aa876;
}
</style> 