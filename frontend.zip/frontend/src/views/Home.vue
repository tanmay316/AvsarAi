<script setup lang="ts">
import { ref } from 'vue';
import { useRouter } from 'vue-router';

const router = useRouter();
const stats = ref({
  jobsApplied: 2500,
  users: 5
});

const features = ref([
  {
    title: 'Share a Job Link',
    description: 'Simply paste any job listing URL from any job board or company career page. Avsar AI immediately analyzes the job requirements and company details.',
    icon: '🔗'
  },
  {
    title: 'AI Fills Applications',
    description: 'Our advanced AI controls your browser to complete application forms, tailoring your resume and answers to match the job requirements perfectly.',
    icon: '🤖'
  },
  {
    title: 'Review and Submit',
    description: 'Before final submission, you can review and make any adjustments. With one click, your application is submitted.',
    icon: '✅'
  }
]);

const benefits = ref([
  {
    title: 'Works with company career pages',
    icon: '🏢'
  },
  {
    title: 'Compatible with all major job boards',
    icon: '📋'
  },
  {
    title: 'Handles complex application forms',
    icon: '📝'
  }
]);
</script>

<template>
  <div class="home">
    <!-- Hero Section -->
    <section class="hero py-20 px-4 relative">
      <div class="hero-content">
        <h1 class="hero-title">Apply to Jobs with One Click</h1>
        <p class="hero-subtitle">
          Avsar AI automates your job applications, letting you apply to hundreds of positions with just a link. 
          Built for the modern job seeker.
        </p>
        <div class="hero-buttons">
          <button class="primary-button" @click="router.push('/apply')">APPLY NOW</button>
          <button class="secondary-button">See How It Works</button>
        </div>
        <div class="stats">
          <div class="stat-item">
            <span class="stat-number">{{ stats.jobsApplied }}+</span>
            <span class="stat-label">jobs applied to today</span>
          </div>
        </div>
      </div>
      <div class="hero-3d">
        <div class="tech-person"></div>
        <div class="floating-cube"></div>
        <div class="floating-sphere"></div>
        <div class="tech-rings"></div>
      </div>
    </section>

    <!-- How It Works Section -->
    <section class="how-it-works py-20 px-4">
      <h2 class="section-title">How Avsar AI Works</h2>
      <p class="section-subtitle">
        Our AI-powered platform streamlines your job search, making applications effortless and efficient.
      </p>
      <div class="features-grid">
        <div v-for="(feature, index) in features" :key="index" class="feature-card">
          <div class="feature-icon">{{ feature.icon }}</div>
          <h3 class="feature-title">{{ feature.title }}</h3>
          <p class="feature-description">{{ feature.description }}</p>
        </div>
      </div>
    </section>

    <!-- Benefits Section -->
    <section class="benefits py-20 px-4">
      <h2 class="section-title">AI Agents for Any Job Posting</h2>
      <p class="section-subtitle">
        Unlike other platforms, Avsar AI works with any job posting on the internet, not just popular job boards.
      </p>
      <div class="benefits-grid">
        <div v-for="(benefit, index) in benefits" :key="index" class="benefit-card">
          <div class="benefit-icon">{{ benefit.icon }}</div>
          <h3 class="benefit-title">{{ benefit.title }}</h3>
        </div>
      </div>
    </section>

    <!-- CTA Section -->
    <section class="cta py-20 px-4">
      <h2 class="cta-title">Ready to Revolutionize Your Job Search?</h2>
      <p class="cta-subtitle">
        Join thousands of Gen Z job seekers who are landing interviews faster with Avsar AI.
      </p>
      <button class="primary-button" @click="router.push('/apply')">APPLY NOW</button>
      <p class="cta-note">No credit card required</p>
    </section>
  </div>
</template>

<style scoped>
.home {
  font-family: 'Space Grotesk', sans-serif;
  color: var(--text);
  background-color: var(--darker);
  overflow-x: hidden;
}

/* Hero Section */
.hero {
  display: flex;
  justify-content: space-between;
  align-items: center;
  min-height: 100vh;
  position: relative;
  overflow: hidden;
}

.hero::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: linear-gradient(135deg, 
    rgba(108, 99, 255, 0.1),
    rgba(0, 217, 255, 0.1),
    rgba(255, 61, 113, 0.1)
  );
  z-index: -1;
}

.hero-content {
  max-width: 600px;
  z-index: 1;
}

.hero-title {
  font-size: 4rem;
  font-weight: 800;
  background: linear-gradient(45deg, 
    var(--primary),
    var(--secondary),
    var(--accent)
  );
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  margin-bottom: 1.5rem;
  animation: glow 2s ease-in-out infinite alternate;
}

.hero-subtitle {
  font-size: 1.25rem;
  color: var(--text);
  margin-bottom: 2rem;
  line-height: 1.6;
}

.hero-buttons {
  display: flex;
  gap: 1rem;
  margin-bottom: 3rem;
}

.primary-button {
  padding: 1rem 2rem;
  background: linear-gradient(45deg, 
    var(--primary),
    var(--secondary),
    var(--accent)
  );
  color: var(--darker);
  border: none;
  border-radius: 0.5rem;
  font-size: 1rem;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;
  position: relative;
  overflow: hidden;
}

.primary-button::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: linear-gradient(45deg, 
    rgba(255, 255, 255, 0.1),
    rgba(255, 255, 255, 0.2)
  );
  transform: translateX(-100%);
  transition: transform 0.3s ease;
}

.primary-button:hover::before {
  transform: translateX(100%);
}

.primary-button:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 20px rgba(108, 99, 255, 0.4);
}

.secondary-button {
  padding: 1rem 2rem;
  background: transparent;
  color: var(--text);
  border: 2px solid var(--primary);
  border-radius: 0.5rem;
  font-size: 1rem;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;
}

.secondary-button:hover {
  background: rgba(108, 99, 255, 0.1);
  transform: translateY(-2px);
}

.stats {
  display: flex;
  gap: 2rem;
}

.stat-item {
  display: flex;
  flex-direction: column;
  align-items: center;
}

.stat-number {
  font-size: 2.5rem;
  font-weight: 700;
  background: linear-gradient(45deg, 
    var(--primary),
    var(--secondary)
  );
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
}

.stat-label {
  color: var(--text);
  font-size: 0.875rem;
}

/* 3D Objects */
.hero-3d {
  position: relative;
  width: 600px;
  height: 600px;
}

.tech-person {
  position: absolute;
  width: 300px;
  height: 300px;
  background: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 3c1.66 0 3 1.34 3 3s-1.34 3-3 3-3-1.34-3-3 1.34-3 3-3zm0 14.2c-2.5 0-4.71-1.28-6-3.22.03-1.99 4-3.08 6-3.08 1.99 0 5.97 1.09 6 3.08-1.29 1.94-3.5 3.22-6 3.22z" fill="%236C63FF"/></svg>') no-repeat center center;
  background-size: contain;
  animation: float 6s ease-in-out infinite;
  filter: drop-shadow(0 0 20px rgba(108, 99, 255, 0.5));
}

.floating-cube {
  position: absolute;
  width: 150px;
  height: 150px;
  background: linear-gradient(45deg, 
    var(--primary),
    var(--secondary)
  );
  transform: rotate(45deg);
  animation: float 4s ease-in-out infinite reverse;
  filter: drop-shadow(0 0 15px rgba(108, 99, 255, 0.4));
}

.floating-sphere {
  position: absolute;
  width: 100px;
  height: 100px;
  background: radial-gradient(circle at 30% 30%, 
    var(--primary),
    var(--secondary)
  );
  border-radius: 50%;
  right: 0;
  bottom: 0;
  animation: float 3s ease-in-out infinite;
  filter: drop-shadow(0 0 15px rgba(0, 217, 255, 0.4));
}

.tech-rings {
  position: absolute;
  width: 400px;
  height: 400px;
  border: 2px solid rgba(108, 99, 255, 0.2);
  border-radius: 50%;
  animation: rotate 20s linear infinite;
}

.tech-rings::before,
.tech-rings::after {
  content: '';
  position: absolute;
  border: 2px solid rgba(0, 217, 255, 0.2);
  border-radius: 50%;
  animation: rotate 15s linear infinite reverse;
}

.tech-rings::before {
  width: 300px;
  height: 300px;
  top: 50px;
  left: 50px;
}

.tech-rings::after {
  width: 200px;
  height: 200px;
  top: 100px;
  left: 100px;
}

/* How It Works Section */
.how-it-works {
  background: linear-gradient(135deg, 
    rgba(108, 99, 255, 0.1),
    rgba(0, 217, 255, 0.1)
  );
}

.section-title {
  text-align: center;
  font-size: 3rem;
  font-weight: 700;
  background: linear-gradient(45deg, 
    var(--primary),
    var(--secondary)
  );
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  margin-bottom: 1rem;
}

.section-subtitle {
  text-align: center;
  color: var(--text);
  max-width: 600px;
  margin: 0 auto 3rem;
}

.features-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 2rem;
  max-width: 1200px;
  margin: 0 auto;
}

.feature-card {
  background: rgba(255, 255, 255, 0.05);
  padding: 2rem;
  border-radius: 1rem;
  border: 1px solid rgba(255, 255, 255, 0.1);
  transition: all 0.3s ease;
  backdrop-filter: blur(10px);
}

.feature-card:hover {
  transform: translateY(-5px);
  box-shadow: 0 8px 32px rgba(108, 99, 255, 0.2);
  border-color: var(--primary);
}

.feature-icon {
  font-size: 2.5rem;
  margin-bottom: 1rem;
}

.feature-title {
  font-size: 1.5rem;
  font-weight: 600;
  margin-bottom: 1rem;
  color: var(--primary);
}

.feature-description {
  color: var(--text);
  line-height: 1.6;
}

/* Benefits Section */
.benefits {
  background: linear-gradient(135deg, 
    rgba(0, 217, 255, 0.1),
    rgba(255, 61, 113, 0.1)
  );
}

.benefits-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 2rem;
  max-width: 1200px;
  margin: 0 auto;
}

.benefit-card {
  background: rgba(255, 255, 255, 0.05);
  padding: 2rem;
  border-radius: 1rem;
  border: 1px solid rgba(255, 255, 255, 0.1);
  text-align: center;
  transition: all 0.3s ease;
  backdrop-filter: blur(10px);
}

.benefit-card:hover {
  transform: translateY(-5px);
  box-shadow: 0 8px 32px rgba(0, 217, 255, 0.2);
  border-color: var(--secondary);
}

.benefit-icon {
  font-size: 2.5rem;
  margin-bottom: 1rem;
}

.benefit-title {
  font-size: 1.5rem;
  font-weight: 600;
  color: var(--secondary);
}

/* CTA Section */
.cta {
  text-align: center;
  background: linear-gradient(135deg, 
    rgba(255, 61, 113, 0.1),
    rgba(108, 99, 255, 0.1)
  );
}

.cta-title {
  font-size: 3rem;
  font-weight: 700;
  background: linear-gradient(45deg, 
    var(--accent),
    var(--primary)
  );
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  margin-bottom: 1rem;
}

.cta-subtitle {
  color: var(--text);
  max-width: 600px;
  margin: 0 auto 2rem;
}

.cta-note {
  color: var(--text);
  margin-top: 1rem;
  font-size: 0.875rem;
}

/* Animations */
@keyframes float {
  0%, 100% { transform: translateY(0); }
  50% { transform: translateY(-20px); }
}

@keyframes rotate {
  from { transform: rotate(0deg); }
  to { transform: rotate(360deg); }
}

@keyframes glow {
  from {
    text-shadow: 0 0 10px rgba(108, 99, 255, 0.5),
                 0 0 20px rgba(108, 99, 255, 0.3),
                 0 0 30px rgba(108, 99, 255, 0.2);
  }
  to {
    text-shadow: 0 0 20px rgba(108, 99, 255, 0.8),
                 0 0 30px rgba(108, 99, 255, 0.5),
                 0 0 40px rgba(108, 99, 255, 0.3);
  }
}

/* Responsive Design */
@media (max-width: 768px) {
  .hero {
    flex-direction: column;
    text-align: center;
    padding: 2rem 0;
  }

  .hero-content {
    max-width: 100%;
  }

  .hero-buttons {
    justify-content: center;
  }

  .stats {
    justify-content: center;
  }

  .hero-3d {
    display: none;
  }

  .hero-title {
    font-size: 2.5rem;
  }

  .section-title {
    font-size: 2rem;
  }
}
</style> 